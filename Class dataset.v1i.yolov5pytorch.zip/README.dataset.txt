# Class dataset > 2025-02-17 12:01pm
https://universe.roboflow.com/preethi-w9nes/class-dataset-jfiw7

Provided by a Roboflow user
License: CC BY 4.0

